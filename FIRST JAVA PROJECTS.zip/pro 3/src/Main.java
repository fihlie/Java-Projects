import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) throws FileNotFoundException {
		File f=new File(args[0]);
		File o=new File(args[1]);
		Scanner scan = new Scanner(f);
		String s = scan.nextLine();
		String a="";
		int con=0;
		for(int i=0;i<s.length();i++) {
			if(s.charAt(i)!='-') {
				a+=s.charAt(i);
			}
			else {
				con++;
				a+=" ";
			}
		}
		scan.close();
		int size = (int) Math.sqrt(con+1);
		Scanner other = new Scanner(a);
		int[][] starter = new int[size][size];
		int col = 0;
		int ro = 0;
		HashSet<String> hash = new HashSet<String>();
		int count=0;
		String last="";
		while(other.hasNextInt()) {
			int b = other.nextInt();
			starter[count/size][count%size] = b;
			if (b==0) {
				col = count / size;
				ro = count % size;
			}
			count++;
		}
		other.close();
		Node root = new Node(starter, size, "", "", col, ro);
		Tree tri=new Tree(root);
		for(int i=1;i<count;i++)
			last+=i;
		last+="0";
		
		tri.search(last,hash,o);
	}
}

class Node {
	int column;
	Node left;
	Node parent;
	Node right;
	Node up;
	Node down;
	String path;
	int row;
	int size;
	int[][] data;
	String id="";
	public Node(int[][] data,int size,String old,String letter, int column, int row) {
		path=old+letter;
		this.column = column;
		this.row = row;
		this.size = size;
		this.data = data;
		for(int i=0;i<size;i++) {
			for(int j=0;j<size;j++) {
				id+=data[i][j];
			}
		}
	}
	public int[][] getdata(){
		int [][] ar=new int[size][size];
		for(int i=0;i<size;i++) {
			ar[i]=Arrays.copyOf(data[i], size);
		}
		return ar;
	}
	
	

}
class Tree{
	Node root;
	public Tree(Node root) {
		this.root=root;
	}
	public void search(String table,HashSet<String> set,File x) throws FileNotFoundException {
		PrintStream ps=new PrintStream(x);
		Queue<Node> queue=new LinkedList<Node>();
		queue.add(root);
		while(queue.peek()!=null) {
		Node node = queue.poll();
		if(node.id.equals(table)) {
			ps.println(node.path);
			return;
		}
		int c = node.column;
		int r = node.row;
		
		if (r < node.size - 1) {
			int[][] hello=node.getdata();
			hello[c][r] =hello[c][r + 1];
			hello[c][r + 1] = 0;
			node.right = new Node(hello, node.size, node.path, "R", c, r + 1);
			if(set.add(node.right.id)) {
			queue.add(node.right);
			}
		}
		
		if (r > 0) {
			int[][] hello=node.getdata();
			hello[c][r] = hello[c][r - 1];
			hello[c][r - 1] = 0;
			node.left = new Node(hello, node.size, node.path, "L", c, r - 1);
			if(set.add(node.left.id)) {
			queue.add(node.left);

			}
		}

		if (c > 0) {
			int[][] hello=node.getdata();
			hello[c][r] = hello[c - 1][r];
			hello[c - 1][r] = 0;
			node.up = new Node(hello, node.size, node.path, "U", c - 1, r);
			if(set.add(node.up.id)) {
			queue.add(node.up);
			}
		}
		if (c < node.size - 1) {
			int[][] hello=node.getdata();
			hello[c][r] = hello[c + 1][r];
			hello[c + 1][r] = 0;
			node.down = new Node(hello, node.size, node.path, "D", c + 1, r);
				if(set.add(node.down.id)) {
			queue.add(node.down);
			}
		}
		}
		ps.println("N");
	}
	
}
