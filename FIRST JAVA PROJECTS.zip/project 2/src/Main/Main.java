package Main;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.Scanner;

import CargoTrain.*;
import Util.*;

public class Main {
	File inputFile=new File("input.txt");
	Scanner scan;
	private PrintStream printStream;
	public Main() {
		
	}
	public static void main(String[] args) throws FileNotFoundException{
		File inFile=new File(args[0]);
		File outFile=new File(args[1]);
		Main main = new Main();
		main.execute(inFile,outFile);
	}
	public void readAndInitialize(Train train,PrintStream printStream,File in) throws FileNotFoundException {
		scan = new Scanner(in);
		int length= scan.nextInt();
		int capacity = scan.nextInt();
		int stations= scan.nextInt();
		scan.nextLine();
		train.createStations(stations,printStream);
		while(scan.hasNextLine()) {
			String s= scan.nextLine();
			Scanner newScan= new Scanner(s);
			int cargoId=newScan.nextInt();
			int loadingStationId=newScan.nextInt();
			int targetStationId=newScan.nextInt();
			int size=newScan.nextInt();
			train.getSpesificStation(loadingStationId).addCargoQueue(new Cargo(cargoId,loadingStationId,targetStationId,size));
			newScan.close();
		}
	}
	public void execute(File in,File out) throws FileNotFoundException {
		printStream= new PrintStream(out);
		Scanner scani = new Scanner(in);
		int length= scani.nextInt();
		int capacity = scani.nextInt();
		int stations= scani.nextInt();
		Train train = new Train(length,capacity);
		train.setNumOfSta(stations);
		scani.close();
		readAndInitialize(train,printStream,in);
		for(int i=0;i<stations;i++) {
			train.getSpesificStation(i).process(train);
		}
	}
	
	
}