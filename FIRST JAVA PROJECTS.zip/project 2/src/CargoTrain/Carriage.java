package CargoTrain;
import java.util.Stack;
import Util.*;

public class Carriage{
	private int emptySlot;
	private Stack<Cargo> cargos=new Stack<>();
	private Carriage prev;
	private Carriage next;
	
	public Carriage(int capacity) {
		emptySlot=capacity;
	}
	public boolean isFull() {
		if(emptySlot==0) {
			return true;
		}
		return false;
	}
	public void push(Cargo cargo) {
		cargos.push(cargo);
	}
	public boolean isEmptyStack() {
		if(cargos.size()==0)
			return true;
		else
			return false;
	}
	public Cargo pop() {
		return cargos.pop();
	}

	public Carriage getPrev() {
		return prev;
	}

	public int getEmptySlot() {
		return emptySlot;
	}

	public void setEmptySlot(int emptySlot) {
		this.emptySlot = emptySlot;
	}

	public void setPrev(Carriage prev) {
		this.prev = prev;
	}
	public Carriage getNext() {
		return next;
	}

	public void setNext(Carriage next) {
		this.next = next;
	}
}