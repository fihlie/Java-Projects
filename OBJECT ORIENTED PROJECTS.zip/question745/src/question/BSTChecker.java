// separator	BSTChecker.java_0_false.txt
package question;

import do_not_modify.Node;

public class BSTChecker {

	/**
	 * Given two bsts, checks if they are identical.
	 * @param node1 root of the first bst
	 * @param node2 root of the second bst
	 * @return 1 if two trees are identical; 0 otherwise
	 */
	public static int isIdentical (Node<Integer> node1, Node<Integer> node2) {
		//DO_NOT_EDIT_ANYTHING_ABOVE_THIS_LINE

// separator	BSTChecker.java_1_true.txt
		if(node1==null&&node2==null) {
			return 1;
		}
		else if(node1==null&&node2!=null) {
			return 0;
		}
		else if(node1!=null&&node2==null) {
			return 0;
		}
		else if(node1!=null&&node2!=null) {
			if(node1.data==node2.data) {
				if((isIdentical(node1.leftChild,node2.leftChild)==1&&isIdentical(node1.rightChild,node2.rightChild)==1)){
					return 1;
				}
				else {
					return 0;
				}
			}
			else {
				return 0;
			}
		}
		
		return -1;



// separator	BSTChecker.java_2_false.txt
		//DO_NOT_EDIT_ANYTHING_BELOW_THIS_LINE
	}

	/**
	 * Checks whether the tree rooted at node is a valid bst.
	 * @param node root of the tree
	 * @return 1 if tree is a valid bst; 0 otherwise
	 */
	public static int isValid (Node<Integer> node) {
		//DO_NOT_EDIT_ANYTHING_ABOVE_THIS_LINE

// separator	BSTChecker.java_3_true.txt
		if(node==null) {
			return 1;
		}
		if(node.leftChild==null&&node.rightChild==null) {
			return 1;
		}
		else if(node.leftChild==null&&node.rightChild!=null) {
			if(node.rightChild.data>node.data) {
				return isValid(node.rightChild);
			}
			else {
				return 0;
			}
		}
		else if(node.leftChild!=null&&node.rightChild==null) {
			if(node.leftChild.data<node.data) {
				return isValid(node.leftChild);
			}
			else {
				return 0;
			}
		}
		else if(node.rightChild!=null&&node.leftChild!=null) {
			if(node.rightChild.data>node.data&&node.leftChild.data<node.data) {
				if(isValid(node.leftChild)==1&&isValid(node.rightChild)==1) {
					return 1;
				}
				
				return 0;
			}
			else {
				return 0;
			}
		}
		return -1;



// separator	BSTChecker.java_4_false.txt
		//DO_NOT_EDIT_ANYTHING_BELOW_THIS_LINE
	}

	
	// You can use this area to define the helper methods as you like. 
	// Note that you are not allowed to import any new libraries.

	//DO_NOT_EDIT_ANYTHING_ABOVE_THIS_LINE

// separator	BSTChecker.java_5_true.txt




// separator	BSTChecker.java_6_false.txt
	//DO_NOT_EDIT_ANYTHING_BELOW_THIS_LINE

}

