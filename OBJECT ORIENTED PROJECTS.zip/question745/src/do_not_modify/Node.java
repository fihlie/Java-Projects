package do_not_modify;

public class Node<E> {
	public E data;
	public Node<E> leftChild, rightChild;

	public Node(E data) {
		this.data = data;
	}
}