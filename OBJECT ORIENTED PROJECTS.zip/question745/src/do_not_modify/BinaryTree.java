package do_not_modify;
public class BinaryTree<T extends Comparable<T>> {
	public Node<T> root;

	public void inTraverse() {
		if (root == null) {
			System.out.println("empty!");
		}
		else {
			inTraverse(root);
		}
	}

	private void inTraverse(Node<T> root) {
		if (root != null) {
			inTraverse(root.leftChild);
			System.out.println(root.data);
			inTraverse(root.rightChild);
		}
	}

	public void add(T value) {
		root = add(root, value);
	}

	private Node<T> add(Node<T> current, T data) {
		if (current == null) {
			return new Node<T>(data);
		}

		int comparison = data.compareTo(current.data);
		if (comparison < 0) {
			current.leftChild = add(current.leftChild, data);
		} else if (comparison > 0) {
			current.rightChild = add(current.rightChild, data);
		} else {
			// value already exists
			return current;
		}

		return current;
	}
	
	public void delete(T item) {
		root = delete(root, item);
	}
	
	private Node<T> delete(Node<T> current, T data) {
	    if (current == null) {
	        return null;
	    }
	 
	    int comparison = data.compareTo(current.data);
	    if (comparison < 0) {
	        current.leftChild = delete(current.leftChild, data);
	        return current;
	    }
	    else if (comparison > 0) {
	    	current.rightChild = delete(current.rightChild, data);
	    	return current;
	    }
	    else {	// found
	    	if (current.rightChild == null) {	// if right child is null
            	return current.leftChild;
            }
            if (current.leftChild  == null) {	// if left child is null
            	return current.rightChild;
            }
            else {	// if none is null
            	T minRight = getMin(current.rightChild).data;
	        	current.rightChild = delete(current.rightChild, minRight);
	        	current.data = minRight;
            	return current;
            }
	    }
	}

	private Node<T> getMin(Node<T> node){
		Node<T> min = node;
		
		while(min.leftChild != null) {
			min = min.leftChild;
		}
		
		return min;
	}
	
}
