package runnable;

import do_not_modify.BinaryTree;
import do_not_modify.Node;
import question.BSTChecker;

public class Main {

	public static void main(String[] args) {		
		BinaryTree<Integer> bst0 = new BinaryTree<>(), bst1 = new BinaryTree<>(), bst2 = new BinaryTree<>();
		bst0.add(40);
		bst0.add(30);
		bst0.add(50);
		
		bst1.add(40);
		bst1.add(30);
		bst1.add(50);
		
		bst2.add(30);
		bst2.add(40);
		bst2.add(50);
		

		Node<Integer> n0 = new Node<Integer>(30), n1 = new Node<Integer>(40), n2 = new Node<Integer>(50);
		
		n0.leftChild=n1;
		n0.rightChild=n2;
		
		System.out.println(BSTChecker.isIdentical(bst0.root, bst1.root));	// true
		System.out.println(BSTChecker.isIdentical(bst0.root, bst2.root));	// false
		System.out.println(BSTChecker.isValid(n0));	// 40-- 30 --50 is not a valid BST, false
		System.out.println(BSTChecker.isValid(n1));	// a node itself is a valid bst, true
	}

}
