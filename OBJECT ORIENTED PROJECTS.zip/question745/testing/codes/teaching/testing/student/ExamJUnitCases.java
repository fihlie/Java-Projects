
package codes.teaching.testing.student;

import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.junit.runners.MethodSorters;

import do_not_modify.BinaryTree;
import do_not_modify.Node;
import question.BSTChecker;

/* TODO: Import the classes you need for testing */

// Tests will be sorted in lexicographical order. Therefore start the names as "test1_TestName" 
@FixMethodOrder(MethodSorters.NAME_ASCENDING)

@RunWith(JUnit4.class)
public final class ExamJUnitCases extends ExamJUnit {

	@Rule
	public TestName name = new TestName();

	@Test
	public void test0_identicalness() {
		ExamJUnit.testInitialization(1, name.getMethodName(), "Two BSTs are identical or not", "success", 0, 0);
		try {
			String answerStudent = "not success";
			BinaryTree<Integer> bst0 = new BinaryTree<>(), 
					bst1 = new BinaryTree<>(), bst2 = new BinaryTree<>();
			bst0.add(40);
			
			bst1.add(40);
			
			bst2.add(40);
			bst2.add(30);
			if(BSTChecker.isIdentical(bst0.root, bst1.root)==1 && BSTChecker.isIdentical(bst0.root, bst2.root)==0
					&& BSTChecker.isIdentical(bst1.root, bst2.root)==0)
				answerStudent = "success";
			ExamJUnit.testCheck(answerStudent);
		} catch (Exception e) {
			testFailedExecution(e);
		}
	}

	@Test
	public void test1_identicalness() {
		ExamJUnit.testInitialization(2, name.getMethodName(), "Two BSTs are identical or not", "success", 0, 0);
		try {
			String answerStudent = "not success";
			BinaryTree<Integer> bst0 = new BinaryTree<>(), 
					bst1 = new BinaryTree<>(), bst2 = new BinaryTree<>();
			bst0.add(40);
			bst0.add(30);
			bst0.add(50);
			
			bst1.add(40);
			bst1.add(30);
			bst1.add(50);
			
			bst2.add(30);
			bst2.add(40);
			bst2.add(50);
			if(BSTChecker.isIdentical(bst0.root, bst1.root)==1 && BSTChecker.isIdentical(bst0.root, bst2.root)==0)
				answerStudent = "success";
			ExamJUnit.testCheck(answerStudent);
		} catch (Exception e) {
			testFailedExecution(e);
		}
	}

	@Test
	public void test2_validity() {
		ExamJUnit.testInitialization(3, name.getMethodName(), "Single node is a valid BST", "success", 0, 0);
		try {
			String answerStudent = "not success";
			Node<Integer> n0 = new Node<Integer>(30);
			
			if(BSTChecker.isValid(n0)==1)
				answerStudent = "success";
			ExamJUnit.testCheck(answerStudent);
		} catch (Exception e) {
			testFailedExecution(e);
		}
	}

	@Test
	public void test3_validity() {
		ExamJUnit.testInitialization(4, name.getMethodName(), "A tree is a valid BST or not", "success", 0, 0);
		try {
			String answerStudent = "not success";
			Node<Integer> n0 = new Node<Integer>(30), n1 = new Node<Integer>(40), n2 = new Node<Integer>(50), 
					n3 = new Node<Integer>(30), n4 = new Node<Integer>(40), n5 = new Node<Integer>(50);
			
			n0.leftChild=n1;
			n0.rightChild=n2;
			n4.leftChild=n3;
			n4.rightChild=n5;
			
			if(BSTChecker.isValid(n0)==0 && BSTChecker.isValid(n4)==1)
				answerStudent = "success";
			ExamJUnit.testCheck(answerStudent);
		} catch (Exception e) {
			testFailedExecution(e);
		}
	}
}
