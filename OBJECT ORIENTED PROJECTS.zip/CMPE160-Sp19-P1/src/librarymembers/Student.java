package librarymembers;

import java.util.*;
import books.*;

/**
 * contains constructor for student and a method to get the history of that student.
 */
public class Student extends LibraryMember {

/**
 *  student constructor
 * @param id student's id
 */
	public Student(int id) {
		super(id);
		super.setMemberType("S");
		super.setTimeLimit(20);
		super.setMaxNumberOfBooks(10);
	}

	/**
	 * @see librarymembers.LibraryMember#getTheHistory()
	 */
	public ArrayList<Book> getTheHistory() {
		return super.getHistoryList();
	}

}