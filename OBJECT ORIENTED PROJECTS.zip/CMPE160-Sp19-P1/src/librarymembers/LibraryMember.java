  package librarymembers;

import java.util.*;
import books.*;
/**
 * contains constructor for library member and several methods for them.
 */
public abstract class LibraryMember {
	/**
	 * member's id
	 */
	private int id;
	/**
	 * max number of books that a member can borrow simultaneously.
	 */
	private int maxNumberOfBooks;
	/**
	 * member's time limit to return the borrowed book back to library.
	 */
	private int timeLimit;
	/**
	 * member's currently borrowed books. 
	 */
	private ArrayList<Book> bookList = new ArrayList<Book>();
	/**
	 * member's type student("S" or academic("A").
	 */
	private String MemberType;
	/**
	 * member's history that contain all the books he read and borrowed.
	 */
	private ArrayList<Book> HistoryList = new ArrayList<Book>();


	/**
	 * constructor for library member
	 * @param id member's id
	 */
	public LibraryMember(int id) {
		this.setId(id);
		
	}

	/**
	 * allows other class to see member's history.
	 * @return history list which holds the member's history.
	 */
	public abstract ArrayList<Book> getTheHistory();

	public int getMaxNumberOfBooks() {
		return maxNumberOfBooks;
	}

	public void setMaxNumberOfBooks(int maxNumberOfBooks) {
		this.maxNumberOfBooks = maxNumberOfBooks;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getTimeLimit() {
		return timeLimit;
	}

	public void setTimeLimit(int timeLimit) {
		this.timeLimit = timeLimit;
	}

	public ArrayList<Book> getBookList() {
		return bookList;
	}

	/**
	 * adds the book to member's book list
	 * @param book will be added to member's book list
	 */
	public void addBookList(Book book) {
		this.bookList.add(book);
	}

	/**
	 * removes the book from member's book list
	 * @param book will be removed from member's book list
	 */
	public void removeBookList(Book book) {
		this.bookList.remove(bookList.indexOf(book));
	}

	public String getMemberType() {
		return MemberType;
	}

	public void setMemberType(String memberType) {
		MemberType = memberType;
	}

	/**
	 * checks the member whether (S)he has a book due or not.
	 * @param tick the unit of time
	 * @return true or false
	 */
	public boolean isIrresponsible(int tick) {
		for (int i = 0; i < this.bookList.size(); i++) {
			if ((this.bookList.get(i)).getBookType().equals("P")) {
				if (((Printed) this.bookList.get(i)).getDeadLine() < tick) {
					return true;
				}
			}
		}
		return false;

	}

	/**
	 * add book to member's history list
	 * @param book will be adde to member's history
	 */
	public void addHistory(Book book) {
		if (!HistoryList.contains(book)) {
			HistoryList.add(book);
		}
	}
	public ArrayList<Book> getHistoryList(){
		return HistoryList;
	}
}
