package librarymembers;

import java.util.*;
import books.*;
/**
 * contains constructor for academic and a method to get the history of that academic.
 */
public class Academic extends LibraryMember {
	/**
	 *constructor for academic. 
	 * @param id academic's id.
	 */
	public Academic(int id) {
		super(id);
		super.setMemberType("A");
		super.setTimeLimit(50);
		super.setMaxNumberOfBooks(20);
	}

	/**
	 * @see librarymembers.LibraryMember#getTheHistory()
	 */
	public ArrayList<Book> getTheHistory() {
		return super.getHistoryList();
	}
	
}