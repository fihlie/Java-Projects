package books;

import librarymembers.*;
/**
 * has a constructor for book and its methods
 */
public abstract class Book{
	/**
	 * id of book
	 */
	private int bookID;
	/**
	 * type of book
	 */
	private String bookType;
	/**
	 * book's situation (taken or not)
	 */
	private boolean isTaken;
	/**
	 * holds who has the book
	 */
	private LibraryMember whoHas;
	
	/**
	 * constructor of book
	 * @param bookID id of book
	 * @param bookType type of book
	 */
	public Book(int bookID, String bookType){
		this.bookID=bookID;
		this.bookType=bookType;
		isTaken=false;
		whoHas=null;
	}
	/**
	 * returns the book
	 * @param member library member
	 */
	public abstract void returnBook(LibraryMember member);

	public int getBookID() {
		return bookID;
	}
	
	public String getBookType() {
		return bookType;
	}
	

	public LibraryMember getWhoHas() {
		return whoHas;
	}

	public void setWhoHas(LibraryMember whoHas) {
		this.whoHas = whoHas;
	}

	public boolean isTaken() {
		return isTaken;
	}

	public void setTaken(boolean isTaken) {
		this.isTaken = isTaken;
	}
}