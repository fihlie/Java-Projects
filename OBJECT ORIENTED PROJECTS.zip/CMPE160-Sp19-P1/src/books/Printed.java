package books;

import librarymembers.*;
import interfaces.*;
/**
 * has a constructor for printed book and some of its methods
 */
public class Printed extends Book implements Borrow,ReadInLibrary{
	/**
	 * book's deadline
	 */
	private int deadLine;
	/**
	 * if book is extended or not
	 */
	private boolean isExtended;
	
	/**
	 * printed book's constructor
	 * @param bookID  book's id
	 */
	public Printed (int bookID) {
		super(bookID,"P");
		deadLine=0;
		isExtended=false;
	}
	/**
	 * @see books.Book#returnBook(librarymembers.LibraryMember)
	 */
	public void returnBook(LibraryMember member) {
		super.setTaken(false);
		super.setWhoHas(null);
	}
	/**
	 * @see interfaces.Borrow#extend(librarymembers.LibraryMember, int)
	 */
	public void extend(LibraryMember member, int tick) {
		deadLine=deadLine+member.getTimeLimit();
	}
	/**
	 * @see interfaces.ReadInLibrary#readBook(librarymembers.LibraryMember)
	 */
	public void readBook(LibraryMember member) {
		super.setTaken(true);
		super.setWhoHas(member);
	}
	/**
	 * @see interfaces.Borrow#borrowBook(librarymembers.LibraryMember, int)
	 */
	public void borrowBook(LibraryMember member, int tick) {
		super.setWhoHas(member);
		super.setTaken(true);
		deadLine=tick+member.getTimeLimit();
	}

	public int getDeadLine() {
		return deadLine;
	}

	public void setDeadLine(int deadLine) {
		this.deadLine = deadLine;
	}
	
	public boolean isExtended() {
		return isExtended;
	}
	public void setExtended(boolean isExtended) {
		this.isExtended = isExtended;
	}
}