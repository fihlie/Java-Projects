package books;

import librarymembers.*;
import interfaces.*;
/**
 *  has a constructor for handwritten book and some of its methods
 */
public class Handwritten extends Book implements ReadInLibrary {

	/**
	 * constructor for handwritten book
	 * @param bookID book's id
	 */
	public Handwritten(int bookID) {
		super(bookID,"H");
	}
	/**
	 * @see books.Book#returnBook(librarymembers.LibraryMember)
	 */
	public void returnBook(LibraryMember member) {
		super.setTaken(false);
		super.setWhoHas(null);
	}
	/**
	 * @see interfaces.ReadInLibrary#readBook(librarymembers.LibraryMember)
	 */
	public void readBook(LibraryMember member) {
		super.setTaken(true);
		super.setWhoHas(member);
	}
	
}