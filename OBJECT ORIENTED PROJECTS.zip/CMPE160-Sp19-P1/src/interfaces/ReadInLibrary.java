package interfaces;

import librarymembers.LibraryMember;

public interface ReadInLibrary {
	
	public void readBook(LibraryMember member);
	
}
