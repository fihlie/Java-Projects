package library;

import java.util.*;
import books.*;
import librarymembers.*;

/**
 * implements the fields and methods for a library to work properly.
 */
public class Library {
	/**
	 * Book array for all books registered to library.
	 */
	private Book[] Book = new Book[(int) Math.pow(10, 6)];
	/**
	 * Member array for all members registered to library.
	 */
	private LibraryMember[] LibraryMember = new LibraryMember[(int) Math.pow(10, 6)];
	/**
	 * Holds the total fee paid to the library.
	 */
	private int totalFee;
	/**
	 * Holds the next member id that will be registered to library. 
	 */
	private int id;
	/**
	 * Holds the next book id that will be registered to library.
	 */
	private int bookID;
	/**
	 * Scans the variables in the file.
	 */
	Scanner Scanner;

	/**
	 * Creates a library object.
	 * @param Scanner will be initialized in Main.java and scans the file.
	 */
	public Library(Scanner Scanner) {
		this.Scanner = Scanner;

	}

	/**
	 * Registers new book in the library.
	 */
	public void addBook() {
		if (bookID < 999999) {
			bookID++;
			Book b;
			if (Scanner.next().toUpperCase().equals("P")) {
				b = new Printed(bookID);
			} else {
				b = new Handwritten(bookID);
			}
			Book[bookID - 1] = b;

		}

	}

	/**
	 * Registers new member in the library.
	 */
	public void addMember() {
		if (id < 999999) {
			id++;
			LibraryMember member;
			if (Scanner.next().toUpperCase().equals("S")) {
				member = new Student(id);
			} else {
				member = new Academic(id);
			}
			this.LibraryMember[id - 1] = member;
		}
	}

	/**
	 * Checks the conditions and get the member borrow the book.
	 * @param tick holds the time unit.
	 */
	public void borrowBook(int tick) {
		int bookID = Scanner.nextInt();
		int id = Scanner.nextInt();
		if (Book[bookID - 1] != null && LibraryMember[id - 1] != null) {
			if (LibraryMember[id - 1].isIrresponsible(tick) == false) {
				if (Book[bookID - 1].getBookType().equals("P")) {
					if (LibraryMember[id - 1].getMaxNumberOfBooks() > LibraryMember[id - 1].getBookList().size()
							&& Book[bookID - 1].getWhoHas() == null) {
						LibraryMember[id-1].addHistory(Book[id-1]);
						((Printed) Book[bookID - 1]).borrowBook(LibraryMember[id - 1], tick);
						LibraryMember[id - 1].addBookList(Book[bookID - 1]);
					}
				}
			}
		}
	}

	/**
	 * Checks the conditions and get the member return the book.
	 * @param tick holds the time unit.
	 */
	public void returnBook(int tick) {
		int bookID = Scanner.nextInt();
		int id = Scanner.nextInt();
		if (Book[bookID - 1] != null && LibraryMember[id - 1] != null) {
			if (Book[bookID - 1].getWhoHas().getId()==LibraryMember[id - 1].getId()) {
				if (Book[bookID - 1].getBookType().equals("P")) {
					if (((Printed) Book[bookID - 1]).getDeadLine() != 0
							&& ((Printed) Book[bookID - 1]).getDeadLine() < tick) {
						totalFee += tick - ((Printed) Book[bookID - 1]).getDeadLine();
					}
					if(((Printed)Book[bookID-1]).getDeadLine()!=0) {
						LibraryMember[id-1].removeBookList(Book[bookID-1]);
						}
					((Printed) Book[bookID - 1]).returnBook(LibraryMember[id - 1]);
					((Printed) Book[bookID - 1]).setExtended(false);
					((Printed) Book[bookID - 1]).setDeadLine(0);
					
				}
				if (Book[bookID - 1].getBookType().equals("H")) {
					Book[bookID - 1].returnBook(LibraryMember[id - 1]);

				}
			}
		}
	}

	/**
	 * Allows the other classes to see the total fee.
	 * @return total fee of library.
	 */
	public int getTotalFee() {
		return totalFee;
	}

	/**
	 * Checks the conditions and get members to extend their book.
	 * @param tick holds the time unit.
	 */
	public void extendBook(int tick) {
		int bookID = Scanner.nextInt();
		int id = Scanner.nextInt();
		if (Book[bookID - 1] != null && LibraryMember[id - 1] != null) {
			if (Book[bookID - 1].getWhoHas().getId()==(LibraryMember[id - 1].getId())
					&& ((Printed) Book[bookID - 1]).isExtended() == false
					&&((Printed)Book[bookID-1]).getDeadLine()>tick) {
				((Printed) Book[bookID - 1]).setExtended(true);
				((Printed) Book[bookID - 1]).extend(LibraryMember[id - 1], tick);
			}
		}
	}

	/**
	 * Checks the conditions and get the members read in the library.
	 */
	public void readInLibrary() {
		int bookID = Scanner.nextInt();
		int id = Scanner.nextInt();
		if (Book[bookID - 1] != null && LibraryMember[id - 1] != null) {
			if (Book[bookID - 1].getWhoHas() == null) {
				if (Book[bookID - 1].getBookType().equals("H")) {
					if (LibraryMember[id - 1].getMemberType().equals("A")) {
						LibraryMember[id-1].addHistory(Book[id-1]);
						((Handwritten) Book[bookID - 1]).readBook(LibraryMember[id - 1]);
					}
				}
				if (Book[bookID - 1].getBookType().equals("P")) {
					LibraryMember[id-1].addHistory(Book[id-1]);
					((Printed) Book[bookID - 1]).readBook(LibraryMember[id - 1]);

				}
			}
		}
	}
	public Book[] getBooks() {
		return this.Book;
	}
	public LibraryMember[] getMembers() {
		return this.LibraryMember;
	}
}