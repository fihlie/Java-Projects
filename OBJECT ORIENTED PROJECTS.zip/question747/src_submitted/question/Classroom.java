
package question;

public class Classroom {
	//DO_NOT_EDIT_ANYTHING_ABOVE_THIS_LINE

	private String room;
	private final int maxCapacity;	


	//DO_NOT_EDIT_ANYTHING_BELOW_THIS_LINE
	
	public Classroom(String room, int maxCapacity) {
		this.room = room;
		this.maxCapacity = maxCapacity;
	}

	/**
	 * @return the room
	 */
	public String getRoom() {
		return room;
	}

	/**
	 * @param room the room to set
	 */
	public void setRoom(String room) {
		this.room = room;
	}

	/**
	 * @return the maxCapacity
	 */
	public int getMaxCapacity() {
		return maxCapacity;
	}
	
	@Override
	public String toString() {
		return getRoom();
	}
}

