
package question;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;
import java.util.TreeSet;

import do_not_modify.Course;
import do_not_modify.ExamQuestion;


public class Exam {
	public Course course;	
	public TreeSet<Student> examStudentList;
	public TreeMap<Integer, ExamQuestion> examQuestionList;
	public TreeMap<Student, Double> examResult;
	public List<Classroom> examLocations;
	public int examDuration;

	public Exam(int examDuration, Course course) {
		this.course = course;
		this.examDuration = examDuration;
		this.examStudentList = new TreeSet<Student>();
		this.examQuestionList = new TreeMap<Integer, ExamQuestion>();
		this.examResult = new TreeMap<Student, Double>();
		this.examLocations = new ArrayList<Classroom>();
	}
	
	public void addNewQuestion(ExamQuestion newQuestion) {
		examQuestionList.put(newQuestion.getQuestionOrder(), newQuestion);
	}
	
	public void addNewExamLocation(Classroom newClass) {
		examLocations.add(newClass);
	}
	
	public void addStudentToExam(Student newStudent) {
		examStudentList.add(newStudent);
	}
	
	public void gradeExam() {
		//DO_NOT_EDIT_ANYTHING_ABOVE_THIS_LINE
		for(Student stu:examStudentList) {
			double a=0;
		for(int i:this.examQuestionList.keySet()) {
				if(this.examQuestionList.get(i).isCorrect(stu)) {
					a+=this.examQuestionList.get(i).getQuestionTotalPoint();
				}
			}
		this.examResult.put(stu,a);
		}
		
		


		//DO_NOT_EDIT_ANYTHING_BELOW_THIS_LINE
		
	}
	
	public Double calculateAverage() {
		//DO_NOT_EDIT_ANYTHING_ABOVE_THIS_LINE
		double i=0;
		double b=0;
		for(Student stu:examResult.keySet()) {
			if(examResult.get(stu)!=0) {
				i++;
				b+=examResult.get(stu);
			}
		}
		
		return b/i;	


		//DO_NOT_EDIT_ANYTHING_BELOW_THIS_LINE
	}

}

