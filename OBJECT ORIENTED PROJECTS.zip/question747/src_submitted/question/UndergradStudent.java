
package question;

public class UndergradStudent extends Student {
	
	private int id;

	public UndergradStudent(int id, String name, String surname) {
		super(id, name, surname);
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public int getId() {
		//DO_NOT_EDIT_ANYTHING_ABOVE_THIS_LINE

		return super.getId();


		//DO_NOT_EDIT_ANYTHING_BELOW_THIS_LINE
	}

}

