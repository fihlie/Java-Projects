package do_not_modify;

import java.util.HashMap;

import question.Student;

public class ExamQuestion {
	private int questionOrder;
	private String questionText;
	private String questionCorrectAnswer;
	private HashMap<Student,String> studentAnswerList;
	private int questionTotalPoint;

	/**
	 * @return the questionTotalPoint
	 */
	public int getQuestionTotalPoint() {
		return questionTotalPoint;
	}

	/**
	 * @param questionTotalPoint the questionTotalPoint to set
	 */
	public void setQuestionTotalPoint(int questionTotalPoint) {
		this.questionTotalPoint = questionTotalPoint;
	}

	public ExamQuestion(int questionOrder, String questionText, String questionCorrectAnswer,
			int questionTotalPoint) {
		this.questionOrder = questionOrder;
		this.questionText = questionText;
		this.questionCorrectAnswer = questionCorrectAnswer;
		this.questionTotalPoint = questionTotalPoint;
		this.studentAnswerList = new HashMap<Student, String>();
	}

	/**
	 * @return the questionOrder
	 */
	public int getQuestionOrder() {
		return questionOrder;
	}

	/**
	 * @param questionOrder the questionOrder to set
	 */
	public void setQuestionOrder(int questionOrder) {
		this.questionOrder = questionOrder;
	}

	/**
	 * @return the questionText
	 */
	public String getQuestionText() {
		return questionText;
	}

	/**
	 * @param questionText the questionText to set
	 */
	public void setQuestionText(String questionText) {
		this.questionText = questionText;
	}

	/**
	 * @return the questionCorrectAnswer
	 */
	public String getQuestionCorrectAnswer() {
		return questionCorrectAnswer;
	}

	/**
	 * @param questionCorrectAnswer the questionCorrectAnswer to set
	 */
	public void setQuestionCorrectAnswer(String questionCorrectAnswer) {
		this.questionCorrectAnswer = questionCorrectAnswer;
	}

	/**
	 * @return the answer given by a student
	 */
	public String getStudentAnswer(Student student) {
		return studentAnswerList.get(student);
	}

	/**
	 * @param studentAnswer the studentAnswer to set
	 * @param student the corresponding student 
	 */
	public void answerQuestion(Student student, String studentAnswer) {
		this.studentAnswerList.put(student, studentAnswer);
	}

	/**
	 * 
	 * @return true if student answer and correct answer matches, false otherwise
	 */
	public boolean isCorrect(Student student) {
		return getStudentAnswer(student).equals(getQuestionCorrectAnswer());
	}

}
