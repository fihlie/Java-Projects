package do_not_modify;
import question.Student;

public class GradStudent extends Student {

	public GradStudent(int id, String name, String surname) {
		super(id, name, surname);
	}
	

}
