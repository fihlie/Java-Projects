// separator	UndergradStudent.java_0_false.txt
package question;

public class UndergradStudent extends Student {
	
	private int id;

	public UndergradStudent(int id, String name, String surname) {
		super(id, name, surname);
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public int getId() {
		//DO_NOT_EDIT_ANYTHING_ABOVE_THIS_LINE

// separator	UndergradStudent.java_1_true.txt

		return super.getId();



// separator	UndergradStudent.java_2_false.txt
		//DO_NOT_EDIT_ANYTHING_BELOW_THIS_LINE
	}

}

