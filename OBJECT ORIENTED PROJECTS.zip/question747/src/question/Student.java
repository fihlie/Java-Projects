// separator	Student.java_0_false.txt
package question;
//DO_NOT_EDIT_ANYTHING_ABOVE_THIS_LINE

// separator	Student.java_1_true.txt

public abstract class Student implements Comparable<Student> {



// separator	Student.java_2_false.txt
//DO_NOT_EDIT_ANYTHING_BELOW_THIS_LINE
	private int id;
	private String name;
	private String surname;
	
	public Student(int id, String name, String surname) {
		this.id = id;
		this.name = name;
		this.surname = surname;
	}

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the surname
	 */
	public String getSurname() {
		return surname;
	}

	/**
	 * @param surname the surname to set
	 */
	public void setSurname(String surname) {
		this.surname = surname;
	}
	
	@Override
	public String toString() {
		return getId() + " - " + getName() + " " + getSurname();
	}
	
	@Override
	public boolean equals(Object obj) {
  
        if (obj == this) { 
            return true; 
        } 

        if (!(obj instanceof Student)) { 
            return false; 
        } 
          
        Student tempStudent = (Student) obj; 
        return Integer.compare(this.getId(), tempStudent.getId()) == 0;
	}
	//DO_NOT_EDIT_ANYTHING_ABOVE_THIS_LINE

// separator	Student.java_3_true.txt
	public int compareTo(Student s) {
		 return Integer.compare(this.getId(), s.getId());
		
	}



// separator	Student.java_4_false.txt
	//DO_NOT_EDIT_ANYTHING_BELOW_THIS_LINE
	
	

}

