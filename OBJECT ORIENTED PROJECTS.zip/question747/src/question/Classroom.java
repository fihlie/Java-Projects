// separator	Classroom.java_0_false.txt
package question;

public class Classroom {
	//DO_NOT_EDIT_ANYTHING_ABOVE_THIS_LINE

// separator	Classroom.java_1_true.txt

	private String room;
	private final int maxCapacity;	



// separator	Classroom.java_2_false.txt
	//DO_NOT_EDIT_ANYTHING_BELOW_THIS_LINE
	
	public Classroom(String room, int maxCapacity) {
		this.room = room;
		this.maxCapacity = maxCapacity;
	}

	/**
	 * @return the room
	 */
	public String getRoom() {
		return room;
	}

	/**
	 * @param room the room to set
	 */
	public void setRoom(String room) {
		this.room = room;
	}

	/**
	 * @return the maxCapacity
	 */
	public int getMaxCapacity() {
		return maxCapacity;
	}
	
	@Override
	public String toString() {
		return getRoom();
	}
}

