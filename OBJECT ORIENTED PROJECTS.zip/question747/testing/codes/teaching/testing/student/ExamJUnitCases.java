
package codes.teaching.testing.student;

import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.util.Comparator;
import java.util.TreeMap;
import java.util.TreeSet;

import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.junit.runners.MethodSorters;

import do_not_modify.Course;
import do_not_modify.ExamQuestion;
import do_not_modify.GradStudent;
import question.Exam;
import question.Student;
import question.UndergradStudent;

/* TODO: Import the classes you need for testing */

// Tests will be sorted in lexicographical order. Therefore start the names as "test1_TestName" 
@FixMethodOrder(MethodSorters.NAME_ASCENDING)

@RunWith(JUnit4.class)
public final class ExamJUnitCases extends ExamJUnit {

	@Rule
	public TestName name = new TestName();


	@Test
	public void test1_calculateAverageWithoutZero() {
		ExamJUnit.testInitialization(1, name.getMethodName(), "Calculating the average of an exam, where there is no student with grade 0", "success", 8, 0);
		try {
			String answerStudent = "not success";
			Course course = new Course("CmpE160", "OOP Java");
			Student s1 = new UndergradStudent(2019000001, "Abc", "Def");
			Student s2 = new UndergradStudent(2019000002, "Zzz", "Yyy");
			Student s3 = new UndergradStudent(2019000003, "Aaa", "Bbb");
			Exam cmpe = new Exam(100, course);
			cmpe.examStudentList = new TreeSet<Student>(new Comparator<Student>() 
			{
				@Override
				public int compare(Student o1, Student o2) {
					return Integer.compare(o1.getId(), o2.getId());
				}
			});
			
			cmpe.examResult = new TreeMap<Student, Double>(new Comparator<Student>()
					{
				@Override
				public int compare(Student o1, Student o2) {
					return Integer.compare(o1.getId(), o2.getId());
				}
					});
			cmpe.examResult.put(s1, 37.0);
			cmpe.examResult.put(s2, 5.0);
			cmpe.examResult.put(s3, 3.3);
			if(cmpe.calculateAverage() == 15.1) {
				answerStudent = "success";
			}
			ExamJUnit.testCheck(answerStudent);
		} catch (Exception e) {
			testFailedExecution(e);
		}
	}
	
	@Test
	public void test2_gradeExam() {
		ExamJUnit.testInitialization(2, name.getMethodName(), "Implementing the gradeExam method", 
				"{2019000001 - Emre Akbaba=25.0, 2019000002 - Fernando Muslera=50.0, 2019000003 - Sofiane Feghouli=0.0}", 9, 0);
		try {
			String answerStudent = "not success";
			Course course = new Course("CmpE160", "OOP Java");
			Student s1 = new UndergradStudent(2019000001, "Emre", "Akbaba");
			Student s2 = new UndergradStudent(2019000002, "Fernando", "Muslera");
			Student s3 = new UndergradStudent(2019000003, "Sofiane", "Feghouli");
			ExamQuestion q1 = new ExamQuestion(1, "Inheritance", "correct answer", 25);
			ExamQuestion q2 = new ExamQuestion(2, "AVL Tree", "root", 25);
			
			Exam cmpe = new Exam(100, course);
			
			cmpe.examStudentList = new TreeSet<Student>(new Comparator<Student>() 
			{
				@Override
				public int compare(Student o1, Student o2) {
					return Integer.compare(o1.getId(), o2.getId());
				}
			});
			
			cmpe.examResult = new TreeMap<Student, Double>(new Comparator<Student>()
					{
				@Override
				public int compare(Student o1, Student o2) {
					return Integer.compare(o1.getId(), o2.getId());
				}
					});
			
			cmpe.addNewQuestion(q1);
			cmpe.addNewQuestion(q2);
			
			cmpe.examStudentList.add(s1);
			cmpe.examStudentList.add(s2);
			cmpe.examStudentList.add(s3);
			
			q1.answerQuestion(s1, "dasdas");
			q1.answerQuestion(s2, "correct answer");
			q1.answerQuestion(s3, "correct");
			
			q2.answerQuestion(s1, "root");
			q2.answerQuestion(s2, "root");
			q2.answerQuestion(s3, "rot");
			
			
			cmpe.gradeExam();
			answerStudent = cmpe.examResult.toString();
			ExamJUnit.testCheck(answerStudent);
		} catch (Exception e) {
			testFailedExecution(e);
		}
	}
	
	@Test
	public void test3_undergradID() {
		ExamJUnit.testInitialization(3, name.getMethodName(), "Resolving the bug which causes that the ID of an undergraduate student returns wrong", "success", 8, 0);
		try {
			String answerStudent = "not success";
			Student s1 = new UndergradStudent(2019000001, "Abc", "Def");
			
			if(s1.getId() == 2019000001) {
				answerStudent = "success";
			}
			ExamJUnit.testCheck(answerStudent);
		} catch (Exception e) {
			testFailedExecution(e);
		}
	}
}
