package Util;
import java.io.*;
import java.util.*;
import CargoTrain.Carriage;
import CargoTrain.Train;
public class Station{
	private int id;
	private Queue<Cargo> cargoQueue = new LinkedList<>();
	private Queue<Cargo> subQueue=new LinkedList<>();
	private PrintStream printStream;
	public Station(int id,PrintStream printStream) throws FileNotFoundException {
		this.id=id;
		this.printStream=printStream;
	}
	
	public void process(Train train) throws FileNotFoundException{
		train.unload(cargoQueue);
		while(cargoQueue.peek()!=null) {
			Cargo cargo=cargoQueue.remove();
			if(cargo.getTargetStation()==id) {
				printStream.println(cargo.toString());
			}
			else {
				subQueue.add(cargo);
			}
		}
		train.load(subQueue);
		printStream.println(id+" "+train.getLength());
	}
	
	public Queue<Cargo> getCargoQueue() {
		return cargoQueue;
	}

	public void setCargoQueue(Queue<Cargo> cargoQueue) {
		this.cargoQueue = cargoQueue;
	}

	public void addCargoQueue(Cargo cargo) {
		cargoQueue.add(cargo);
	}
	
	 
}