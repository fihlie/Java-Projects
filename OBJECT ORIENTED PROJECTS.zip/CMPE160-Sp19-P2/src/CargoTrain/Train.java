package CargoTrain;

import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Queue;
import Util.*;

public class Train {
	private int carCapacity;
	private int length;
	private Carriage head;
	private Carriage tail;
	private int numOfSta;
	private ArrayList<Station> array = new ArrayList<Station>();

	public Train(int length, int carCapacity) {
		this.setLength(length);
		this.carCapacity = carCapacity;
		if (length == 1) {
			Carriage first = new Carriage(carCapacity);
			head = first;
			tail = first;
			first.setNext(null);
			first.setPrev(null);
		} else if (length == 2) {
			Carriage first = new Carriage(carCapacity);
			Carriage second = new Carriage(carCapacity);
			head = first;
			tail = second;
			first.setPrev(null);
			second.setPrev(first);
			first.setNext(second);
			second.setNext(null);
		} else {
			Carriage first = new Carriage(carCapacity);
			first.setPrev(null);
			head = first;
			int count = 1;
			while (count < length) {
				this.addCarriage();
				count++;
			}
		}
	}

	public void unload(Queue<Cargo> cargos) {
		Carriage curr = head;
		if (length > 1) {
			while (curr != null) {
				while (curr.getEmptySlot() != carCapacity) {
					Cargo carg = curr.pop();
					cargos.add(carg);
					curr.setEmptySlot(curr.getEmptySlot() + carg.getSize());
				}
				curr = curr.getNext();
			}
			
		} else if (length == 1) {
			while (curr.getEmptySlot() != carCapacity) {
				Cargo carg = curr.pop();
				cargos.add(carg);
				curr.setEmptySlot(curr.getEmptySlot() + carg.getSize());
			}
		}

	}

	public void load(Queue<Cargo> cargos) {
		while (cargos.peek() != null) {
			Carriage curr = head;
			Cargo cargo = cargos.remove();
			while (cargo.getSize() > curr.getEmptySlot()) {
				if (curr != tail) {
					curr = curr.getNext();
				} else {
					this.addCarriage();
				}
			}
			curr.push(cargo);
			curr.setEmptySlot(curr.getEmptySlot() - cargo.getSize());

		}
	
		int count=0;
		Carriage car = head;
		while(car!=null&&car.getEmptySlot()!=carCapacity) {
			count++;
			car=car.getNext();
		}
		length=count;
		if(car!=null) {
			tail=car;
			tail.setNext(null);
		}
	}

	public void addCarriage() {
		Carriage last = new Carriage(carCapacity);
		this.tail.setNext(last);
		last.setPrev(tail);
		last.setNext(null);
		tail = last;
	}

	public int getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}

	public void createStations(int stat, PrintStream printStream) throws FileNotFoundException {
		for (int i = 0; i < stat; i++)
			array.add(new Station(i, printStream));
	}

	public Station getSpesificStation(int n) {
		return array.get(n);
	}

	public int getNumOfSta() {
		return numOfSta;
	}

	public void setNumOfSta(int numOfSta) {
		this.numOfSta = numOfSta;
	}

}