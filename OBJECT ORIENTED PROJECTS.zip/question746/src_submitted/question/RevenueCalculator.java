
package question;

import java.util.ArrayList;
import java.util.HashMap;

import do_not_modify.*;
import question.Flight;

public class RevenueCalculator {
	/**
	 * This HashMap contains flight numbers as keys and passenger lists as values
	 */
	HashMap<String, ArrayList<Passenger>> flightNumberToPassengers;
	
	public RevenueCalculator() {
		this.flightNumberToPassengers = new HashMap<>();
	}
	
	public void addFlight(Flight f) {
		this.flightNumberToPassengers.put(f.getFlightNumber(), f.getPassengers());
	}
	
	/**
	 * Calculates and returns the revenue for the given flight number as the sum of ticket price
	 * paid for all passengers of the flight.
	 * @param flightNumber : Flight number as string
	 * @return Revenue for the flight
	 */
	public double calculateRevenueForFlight(String flightNumber) {
		//DO_NOT_EDIT_ANYTHING_ABOVE_THIS_LINE
		int a=0;
		for(Passenger p:this.flightNumberToPassengers.get(flightNumber)) {
			a+=p.getAmountPaid();
		}
		return a;
		


		//DO_NOT_EDIT_ANYTHING_BELOW_THIS_LINE
	}
	
	/**
	 * Calculates the total revenue of every flight in the HashMap flightNumberToPassengers.
	 * @return Total revenue of every flight
	 */
	public double calculateTotalRevenue() {
		//DO_NOT_EDIT_ANYTHING_ABOVE_THIS_LINE
		int a=0;
		for(String flightNumber:this.flightNumberToPassengers.keySet())
			a+=calculateRevenueForFlight(flightNumber);
		return a;
		


		//DO_NOT_EDIT_ANYTHING_BELOW_THIS_LINE
	}
	
}

