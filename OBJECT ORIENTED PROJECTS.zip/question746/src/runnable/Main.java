package runnable;

import do_not_modify.Helper;
import do_not_modify.Passenger;
import question.Flight;
import question.RevenueCalculator;

public class Main {

	public static void main(String[] args) {
		
		Flight f = Helper.generateRandomFlightWithPassengers(1);
		System.out.println(f.getFlightNumber());
		System.out.println(f.getDepartureCity());
		System.out.println(f.getDestinationCity());
		for(Passenger p : f.getPassengers()) {
			System.out.print(p.getAmountPaid() + " ");
		}
	}

}
