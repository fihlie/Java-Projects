package do_not_modify;

import java.util.HashMap;
import java.util.Random;

import question.Flight;

public class Helper {
	
	@SuppressWarnings("serial")
	public static HashMap<String, Integer> citiesToDistances = new HashMap<String, Integer>(){
		{
			put("istanbul-ankara", 400);
			put("istanbul-izmir", 250);
			put("ankara-istanbul", 400);
			put("ankara-izmir", 350);
			put("izmir-istanbul", 250);
			put("izmir-ankara", 350);
		}
	};
	
	public static Passenger generateRandomPassenger(int ID, int seed) {
		
		Random random = new Random(seed);
		
		boolean business = random.nextBoolean();
		
		int baggageKg;
		if(business)
			baggageKg = random.nextInt(50) + 30;
		else
			baggageKg = random.nextInt(30) + 15;
		
		int daysUntilFlight = random.nextInt(60);
		
		return new Passenger(ID, baggageKg, business, daysUntilFlight);
	}
	
	public static Flight generateRandomFlightWithPassengers(int seed) {
		
		Random rand = new Random(seed);
		
		int flightNumber = rand.nextInt(9000) + 1000;
		String flightNo = "DR" + Integer.toString(flightNumber);
		
		int cities = rand.nextInt(6);
		String temp = (String) citiesToDistances.keySet().toArray()[cities];
		String departureCity = temp.substring(0, temp.indexOf('-'));
		String destinationCity = temp.substring(temp.indexOf('-')+1);
		
		Flight f = new Flight(flightNo, departureCity, destinationCity);
		
		int numberOfPassengers = rand.nextInt(60) + 20;
		for(int i=0; i < numberOfPassengers; i++) {
			f.addPassenger(generateRandomPassenger(i, rand.nextInt(1000000)));
		}
		
		return f;
	}
	
	
}
