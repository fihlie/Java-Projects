package do_not_modify;

/**
 * Passenger class:
 * Represents the passenger of a flight.
 */
public class Passenger {
	private int ID;
	private int baggageKg;
	private boolean business;
	private int daysUntilFlight;
	private double amountPaid;
	
	public Passenger() {
		
	}
	
	public Passenger(int ID, int baggageKg, boolean business, int daysUntilFlight) {
		this.ID = ID;
		this.baggageKg = baggageKg;
		this.business = business;
		this.daysUntilFlight = daysUntilFlight;
		this.amountPaid = 0;
	}
	
	public int getID() {
		return ID;
	}
	
	public void setID(int iD) {
		ID = iD;
	}
	
	public int getBaggageKg() {
		return baggageKg;
	}
	
	public void setBaggageKg(int baggageKg) {
		this.baggageKg = baggageKg;
	}
	
	public boolean isBusiness() {
		return business;
	}
	
	public void setBusiness(boolean business) {
		this.business = business;
	}

	public int getDaysUntilFlight() {
		return daysUntilFlight;
	}

	public void setDaysUntilFlight(int daysUntilFlight) {
		this.daysUntilFlight = daysUntilFlight;
	}

	public double getAmountPaid() {
		return amountPaid;
	}

	public void setAmountPaid(double amountPaid) {
		this.amountPaid = amountPaid;
	}
}
