// separator	Flight.java_0_false.txt
package question;

import do_not_modify.Helper;
import do_not_modify.Passenger;
import java.util.ArrayList;


/**
 * 
 * Flight class
 *
 */
public class Flight {
	private String flightNumber;
	private String departureCity;
	private String destinationCity;
	private int distance;
	
	private ArrayList<Passenger> passengers;
	
	/**
	 *  Default constructor
	 */
	public Flight() {
		
	}
	
	public Flight(String flightNumber, String departureCity, String destinationCity) {
		this.flightNumber = flightNumber;
		this.departureCity = departureCity;
		this.destinationCity = destinationCity;
		this.distance = this.calculateDistance();
		
		this.passengers = new ArrayList<>();
	}
	
	/**
	 * Calculates the distances based on the departureCity and the destinationCity
	 * @return distance between the two cities
	 */
	public int calculateDistance() {
		
		//DO_NOT_EDIT_ANYTHING_ABOVE_THIS_LINE

// separator	Flight.java_1_true.txt

		return Helper.citiesToDistances.get(departureCity+"-"+destinationCity);



// separator	Flight.java_2_false.txt
		//DO_NOT_EDIT_ANYTHING_BELOW_THIS_LINE
	}
	
	/**
	 * Calculates the ticket price that the input passenger will pay according to the rules
	 * and formulas given in the question description.
	 * 
	 * @param p : Input passenger
	 * @return Ticket price that the passenger will pay for this flight.
	 */
	public double calculatePriceForPassenger(Passenger p) {
		
		//DO_NOT_EDIT_ANYTHING_ABOVE_THIS_LINE

// separator	Flight.java_3_true.txt
		int a=0;
		if(p.isBusiness()) {
			a+= this.calculateDistance();
			a=a-2*p.getDaysUntilFlight();
			if(p.getBaggageKg()>60) {
				a+=5*(p.getBaggageKg()-60);
			}
			p.setAmountPaid(a);
		}
		else {
			a+=this.calculateDistance()/2;
			a=a-2*p.getDaysUntilFlight();
			if(p.getBaggageKg()>30) {
				a+=15*(p.getBaggageKg()-30);
			}
			p.setAmountPaid(a);
		}
		return a;
		



// separator	Flight.java_4_false.txt
		//DO_NOT_EDIT_ANYTHING_BELOW_THIS_LINE
	}
	
	/**
	 * Calculates the amount paid by the passenger and adds the passenger to the passenger list
	 * @param p : A passenger
	 */
	public void addPassenger(Passenger p) {
		p.setAmountPaid(this.calculatePriceForPassenger(p));
		this.passengers.add(p);
	}
	
	public void removePassenger(Passenger p) {
		this.passengers.remove(p);
	}

	public String getFlightNumber() {
		return flightNumber;
	}

	public void setFlightNumber(String flightNumber) {
		this.flightNumber = flightNumber;
	}

	public String getDepartureCity() {
		return departureCity;
	}

	public void setDepartureCity(String departureCity) {
		this.departureCity = departureCity;
	}

	public String getDestinationCity() {
		return destinationCity;
	}

	public void setDestinationCity(String destinationCity) {
		this.destinationCity = destinationCity;
	}

	public int getDistance() {
		return distance;
	}

	public void setDistance(int distance) {
		this.distance = distance;
	}

	public ArrayList<Passenger> getPassengers() {
		return passengers;
	}

	public void setPassengers(ArrayList<Passenger> passengers) {
		this.passengers = passengers;
	}
}

