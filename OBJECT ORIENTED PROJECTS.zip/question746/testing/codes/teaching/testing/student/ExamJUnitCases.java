package codes.teaching.testing.student;

import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.junit.runners.MethodSorters;

import do_not_modify.*;
import question.*;

/* TODO: Import the classes you need for testing */

// Tests will be sorted in lexicographical order. Therefore start the names as "test1_TestName" 
@FixMethodOrder(MethodSorters.NAME_ASCENDING)

@RunWith(JUnit4.class)
public final class ExamJUnitCases extends ExamJUnit {

	@Rule
	public TestName name = new TestName();


	@Test
	public void test1_calculateDistance() {
		ExamJUnit.testInitialization(1, name.getMethodName(), "Is calculateDistance is working for an istanbul-izmir flight?", "250.0", 5, 0);
		try {
			Flight test = new Flight("DR1234", "istanbul", "izmir");
			
			String answerStudent = Double.toString(test.getDistance());
			ExamJUnit.testCheck(answerStudent);
		} catch (Exception e) {
			testFailedExecution(e);
		}
	}
	
	@Test
	public void test2_calculatePriceForPassenger() {
		ExamJUnit.testInitialization(2, name.getMethodName(), "Is calculatePriceForPassenger method working correctly for a passenger who "
				+ "bought a ticket from istanbul to izmir 12 days before the flight with 35 kgs baggage?", "176.0", 5, 0);
		try {
			Flight test = new Flight("DR1234", "istanbul", "izmir");
			test.addPassenger(new Passenger(0, 35, false, 12));
			double answer = test.getPassengers().get(0).getAmountPaid();
			
			String answerStudent = Double.toString(answer);
			
			ExamJUnit.testCheck(answerStudent);
		} catch (Exception e) {
			testFailedExecution(e);
		}
	}
	
	@Test
	public void test3_calculateRevenueForFlight() {
		ExamJUnit.testInitialization(3, name.getMethodName(), "Is calculateRevenueForFlight method working correctly for an "
				+ "istanbul-izmir flight with 2 passengers: [ID=0, baggageKgs=22, business=false, daysUntilFlight=12] and "
				+ "[ID=1, baggageKgs=72, business=true, daysUntilFlight=22]?", "367.0", 5, 0);
		try {
			Flight test = new Flight("DR1234", "istanbul", "izmir");
			test.addPassenger(new Passenger(0, 22, false, 12));
			test.addPassenger(new Passenger(1, 72, true, 22));
			RevenueCalculator calculator = new RevenueCalculator();
			calculator.addFlight(test);
			
			String answerStudent = Double.toString(calculator.calculateRevenueForFlight(test.getFlightNumber()));
			
			ExamJUnit.testCheck(answerStudent);
		} catch (Exception e) {
			testFailedExecution(e);
		}
	}
	
	@Test
	public void test4_calculateTotalRevenue() {
		ExamJUnit.testInitialization(4, name.getMethodName(), "Is calculateTotalRevenue working correctly with 2 flights and 5 total passengers?\n "
				+ "(Please examine the code of the test case for details)", "1126.0", 5, 0);
		try {
			Flight test = new Flight("DR1234", "istanbul", "izmir");
			test.addPassenger(new Passenger(0, 22, false, 12));
			test.addPassenger(new Passenger(1, 72, true, 22));
			
			Flight test2 = new Flight("DR2244", "istanbul", "ankara");
			test2.addPassenger(new Passenger(0, 11, false, 20));
			test2.addPassenger(new Passenger(1, 31, false, 3));
			test2.addPassenger(new Passenger(2, 27, true, 5));
			
			RevenueCalculator calculator = new RevenueCalculator();
			calculator.addFlight(test);
			calculator.addFlight(test2);
			
			String answerStudent = Double.toString(calculator.calculateTotalRevenue());
			
			ExamJUnit.testCheck(answerStudent);
		} catch (Exception e) {
			testFailedExecution(e);
		}
	}
}
